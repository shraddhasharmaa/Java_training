

public class Check {
	
	public String evenodd(int num) {
		
		if(num%2==0) {
			return "even";
		}else {
			return "odd";
		}
	}

}
