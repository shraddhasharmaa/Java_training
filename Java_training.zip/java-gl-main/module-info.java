module sample {
	public static void main ()
}